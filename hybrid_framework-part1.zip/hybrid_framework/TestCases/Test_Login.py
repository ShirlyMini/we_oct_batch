from selenium.webdriver.chrome.service import Service
from Utility.ReadProperty import Read_Property
from PageObject import LoginPageObject
from Utility.CustomLogger import logger
import pytest
from selenium import webdriver

class Test_login_function_001:
    def test_verify_title(self, launch_browser):
        logg = logger()
        logg.info("TC::test_verify_title")
        self.driver = launch_browser

        logg.info("Successfully Logged in")
        if self.driver.title=="Your store. Login":
            logg.info("TC::test_verify_title=Passed")
            assert True
        else:
            logg.error("TC::test_verify_title=Failed")
            self.driver.save_screenshot(r'.\ScreenShot\test_verify_title.png')
            assert False

    def test_verify_login(self, launch_browser):
        logg = logger()
        logg.info("TC::test_verify_login")
        self.driver = launch_browser
        login_obj=LoginPageObject.Login(self.driver)
        self.usrname = Read_Property.GetUsername()
        self.password = Read_Property.GetPassword()
        login_obj.SetEmail(self.usrname)
        logg.info("Successfully given username")
        login_obj.SetPassword(self.password)
        logg.info("Successfully given password")
        login_obj.ClickLogin()
        logg.info("Login into the application...")
        status = login_obj.VerifyDashbord()
        if status == True:
            login_obj.ClickLogout()
            logg.info("TC::test_verify_login=Passed")
            assert True
        else:
            logg.error("TC::test_verify_login=Failed")
            self.driver.save_screenshot(r'.\ScreenShot\ttest_verify_login.png')
            assert False


