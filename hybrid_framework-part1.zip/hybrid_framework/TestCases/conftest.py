from selenium.webdriver.chrome.service import Service
import pytest
from selenium import webdriver
from Utility.ReadProperty import Read_Property


@pytest.fixture()
def launch_browser():
    service_obj = Service(r"E:\selenium\drivers\chromedriver.exe")
    driver = webdriver.Chrome(service=service_obj)
    base_url = Read_Property.GetURL()
    driver.get(base_url)
    yield driver
    driver.quit()