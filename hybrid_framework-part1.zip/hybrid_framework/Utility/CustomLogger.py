import logging
def logger():
    logging.basicConfig(filename=r".\Logs\test1.log", filemode="a", level=logging.INFO,
                        format="%(levelname)s :: %(asctime)s %(message)s", force=True)
    logging.getLogger()
    return logging