from time import sleep
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

service_obj = Service(r"E:\selenium\drivers\chromedriver.exe")
driver = webdriver.Chrome(service=service_obj)

driver.get("https://cleartax.in/s/simple-compound-interest-calculator")

# drp_down = Select(driver.find_element(By.ID, "a"))
# drp_down.select_by_value("Simple Interest")

inttype_elem = driver.find_element(By.ID, "a")
princi_elem = driver.find_element(By.ID, "c")
rate_elem = driver.find_element(By.ID, "d")
punit_elem = driver.find_element(By.ID, "f")
poption_elem = driver.find_element(By.ID, "e")
total_value_elem = driver.find_element(By.XPATH, "//label[contains(text(),'Total Value')]/following-sibling::span")


int_type_drp_down = Select(inttype_elem)
int_type_drp_down.select_by_visible_text("Simple Interest")


princi_elem.clear()
princi_elem.send_keys("1000")
rate_elem.clear()
rate_elem.send_keys("10")

peroid_unit_drp_down = Select(punit_elem)
peroid_unit_drp_down.select_by_visible_text("Months")

poption_elem.clear()
poption_elem.send_keys("10")

print(total_value_elem.text)

sleep(10)