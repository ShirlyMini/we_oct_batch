import pytest

def test_addition():
    print("this is addition")

def test_subration():
    print("this is subration")

def test_multiplication():
    print("this is multiplication")