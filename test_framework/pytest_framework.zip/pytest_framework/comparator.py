import pytest


def test_greaterthan():
    print("this is greaterthan func")


def test_lesserthan():
    print("this is lesserthan func")


def test_notequalto():
    print("this is notequalto func")