search_name = {"firstname":["James", "Brenda", "Arthur"],
               "lastname":["Smith", "Gates", "Kohli"]}